<?php

VardefManager::addTemplate('abc_Estoppels', 'abc_Estoppels', 'customer_journey_parent', 'abc_Estoppels', true);
