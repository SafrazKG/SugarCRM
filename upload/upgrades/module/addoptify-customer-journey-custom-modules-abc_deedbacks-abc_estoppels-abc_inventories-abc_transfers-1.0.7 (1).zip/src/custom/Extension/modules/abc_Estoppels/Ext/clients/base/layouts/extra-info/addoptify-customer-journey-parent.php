<?php

$module_name = 'abc_Estoppels';

if (SugarAutoLoader::fileExists('custom/include/SugarObjects/implements/customer_journey_parent/clients/base/layouts/extra-info/extra-info.php')) {
    require 'custom/include/SugarObjects/implements/customer_journey_parent/clients/base/layouts/extra-info/extra-info.php';
}
