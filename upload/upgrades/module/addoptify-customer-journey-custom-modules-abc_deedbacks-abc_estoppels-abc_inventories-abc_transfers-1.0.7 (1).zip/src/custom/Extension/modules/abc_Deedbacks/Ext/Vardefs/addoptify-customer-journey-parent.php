<?php

VardefManager::addTemplate('abc_Deedbacks', 'abc_Deedbacks', 'customer_journey_parent', 'abc_Deedbacks', true);
