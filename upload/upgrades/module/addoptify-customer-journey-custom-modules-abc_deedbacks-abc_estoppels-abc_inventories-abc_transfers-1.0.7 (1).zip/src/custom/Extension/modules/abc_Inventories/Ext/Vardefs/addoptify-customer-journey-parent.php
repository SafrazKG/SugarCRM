<?php

VardefManager::addTemplate('abc_Inventories', 'abc_Inventories', 'customer_journey_parent', 'abc_Inventories', true);
