<?php

VardefManager::addTemplate('abc_Transfers', 'abc_Transfers', 'customer_journey_parent', 'abc_Transfers', true);
