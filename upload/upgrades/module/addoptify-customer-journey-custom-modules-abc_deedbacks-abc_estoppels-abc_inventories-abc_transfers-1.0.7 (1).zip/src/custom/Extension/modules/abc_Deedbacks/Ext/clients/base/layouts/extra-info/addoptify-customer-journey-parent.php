<?php

$module_name = 'abc_Deedbacks';

if (SugarAutoLoader::fileExists('custom/include/SugarObjects/implements/customer_journey_parent/clients/base/layouts/extra-info/extra-info.php')) {
    require 'custom/include/SugarObjects/implements/customer_journey_parent/clients/base/layouts/extra-info/extra-info.php';
}
