<?php

SugarAutoLoader::addNamespace('abc_Estoppels\\CustomerJourney\\', 'custom/modules/abc_Estoppels/CustomerJourney/', 'psr4');
