<?php

SugarAutoLoader::addNamespace('abc_Inventories\\CustomerJourney\\', 'custom/modules/abc_Inventories/CustomerJourney/', 'psr4');
