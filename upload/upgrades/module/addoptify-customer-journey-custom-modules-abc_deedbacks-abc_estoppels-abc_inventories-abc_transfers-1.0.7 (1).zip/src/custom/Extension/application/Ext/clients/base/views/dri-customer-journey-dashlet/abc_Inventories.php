<?php

$viewdefs['base']['view']['dri-customer-journey-dashlet']['dashlets'][0]['filter']['module'][] = 'abc_Inventories';
