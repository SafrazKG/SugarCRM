<?php

SugarAutoLoader::addNamespace('abc_Transfers\\CustomerJourney\\', 'custom/modules/abc_Transfers/CustomerJourney/', 'psr4');
