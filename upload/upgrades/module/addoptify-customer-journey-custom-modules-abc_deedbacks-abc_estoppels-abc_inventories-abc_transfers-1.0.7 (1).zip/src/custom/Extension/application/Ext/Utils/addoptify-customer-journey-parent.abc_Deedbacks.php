<?php

SugarAutoLoader::addNamespace('abc_Deedbacks\\CustomerJourney\\', 'custom/modules/abc_Deedbacks/CustomerJourney/', 'psr4');
