<?php

$app_list_strings['dri_workflow_templates_available_modules_list']['abc_Mortgages'] = 'Mortgages';
