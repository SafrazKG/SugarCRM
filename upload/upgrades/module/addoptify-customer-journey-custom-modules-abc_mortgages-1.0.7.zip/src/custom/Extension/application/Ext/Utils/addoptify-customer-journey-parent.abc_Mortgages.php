<?php

SugarAutoLoader::addNamespace('abc_Mortgages\\CustomerJourney\\', 'custom/modules/abc_Mortgages/CustomerJourney/', 'psr4');
