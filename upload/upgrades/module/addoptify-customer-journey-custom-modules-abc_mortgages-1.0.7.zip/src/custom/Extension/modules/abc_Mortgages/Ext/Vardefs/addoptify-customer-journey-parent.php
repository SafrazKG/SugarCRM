<?php

VardefManager::addTemplate('abc_Mortgages', 'abc_Mortgages', 'customer_journey_parent', 'abc_Mortgages', true);
