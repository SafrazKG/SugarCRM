
<?php

require_once 'modules/Administration/QuickRepairAndRebuild.php';
$autoexecute = false;
$show_output = false;
$randc = new RepairAndClear();
$randc->repairAndClearAll(
    array('clearAll'),
    array(translate('LBL_ALL_MODULES')),
    $autoexecute,
    $show_output
);


// abc_Mortgages
ensure_column_exist('abc_mortgages', 'dri_workflow_template_id', array ('type' => 'id'));
ensure_idx_exist('abc_mortgages', 'idx_'.trim(substr(strtolower('abc_mortgages'), 0, 17)).'_cjtpl_id', array ('dri_workflow_template_id'));

ensure_column_exist('dri_workflows', strtolower('abc_Mortgages').'_id', array ('type' => 'id'));
ensure_idx_exist('dri_workflows', 'idx_cj_jry_'.strtolower('abc_Mortgages').'_id', array (strtolower('abc_Mortgages').'_id'));

ensure_idx_removed('dri_workflows', 'idx_'.strtolower('abc_Mortgages').'_id');
ensure_idx_removed('abc_mortgages', 'idx_dri_workflow_template_id');


/**
 * @param string $table
 * @param string $column
 * @param array $def
 */
function ensure_column_exist($table, $column, array $def)
{
    if (!table_has_column($table, $column)) {
        add_column($table, $column, $def);
    }
}

/**
 * @param string $table
 * @param string $column
 * @return bool
 */
function table_has_column($table, $column)
{
    $db = DBManagerFactory::getInstance();
    $columns = $db->get_columns($table);
    return isset($columns[$column]);
}

/**
 * @param string $table
 * @param string $column
 * @param array $def
 */
function add_column($table, $column, array $def)
{
    $db = DBManagerFactory::getInstance();
    $def['name'] = $column;
    $sql = $db->addColumnSQL($table, array ($def));
    cj_query($sql);
}

/**
 * @param string $table
 * @param string $index
 * @param string $sql
 */
function ensure_idx_exist($table, $index, array $fields)
{
    if (!table_has_idx($table, $index)) {
        add_idx($table, $index, $fields);
    }
}

/**
 * @param string $table
 * @param string $index
 * @return bool
 */
function table_has_idx($table, $index)
{
    $db = DBManagerFactory::getInstance();
    $indices = $db->get_indices($table);
    return isset($indices[$index])
        && count($indices[$index]) !== 0;
}

/**
 * @param string $table
 * @param string $index
 * @param array $fields
 */
function add_idx($table, $index, array $fields)
{
    $db = DBManagerFactory::getInstance();
    $indexes = array (array ('name' => $index, 'type' => 'index', 'fields' => $fields));
    $sql = $db->addIndexes($table, $indexes, false);
    cj_query($sql);
}

/**
 * @param string $table
 * @param string $index
 */
function ensure_idx_removed($table, $index)
{
    $db = DBManagerFactory::getInstance();
    if (table_has_idx($table, $index)) {
        $sql = $db->dropIndexes($table, array (array ('name' => $index)), false);
        cj_query($sql);
    }
}

/**
 * @param string $sql
 * @return bool|resource
 */
function cj_query($sql)
{
    $db = DBManagerFactory::getInstance();
    echo " >>> $sql<br>\n";
    return $db->query($sql, true);
}
