# Deploy Helper Plugin
=======================

This plugin allows managing roles/custom fields/reports/dashboards... through Sugar Extension Framework and to Store/Restore fields_meta_data table to/from filesystem.

## Roles Usage
--------------
After installation and Quick Repair & Rebuild there will be new section in Admin 'Custom Roles Rebuild'. Clicking on it will rebuild roles pulled from custom/Extension/application/Ext/CustomRoles/<file>.php

Example

$customRoles['test_role_id'] = array(
    'name' => 'My Test Role', 
    'description' => 'Test role description', 
    'modules' => array(
        'Leads' => array( // module
            'access' => 'enabled', // enabled/disabled
            'admin' => 'normal', // normal/admin/developer/admin_developer
            'delete' => 'owner', // all/owner/none
            'edit' => 'owner', // all/owner/none
            'export' => 'owner', // all/owner/none
            'import' => 'owner', // all/owner/none
            'list' => 'all', // all/owner/none
            'massupdate' => 'none', // all/none
            'view' => 'all', // all/owner/none
            'fields'  => array( // fields acl
                'my_field' => 'readwrite', // none/default/readonly/readwrite/teams_write/teams_read_ownerwrite/teams_readwrite/owner_readwrite/read_ownerwrite/notset
            ),
        ),
    ),
);

or

$customRoles['test_role_id']['modules']['Leads']['access'] = 'disabled'; // if role doesn't exist it will be created with name 'Role without name'


If some of actions in module are omitted they will not be set (will be left as they are).

After changing custom/Extension/application/Ext/CustomRoles/<file>.php Quick Repair & Rebuild must be done before clicking on 'Custom Roles Rebuild' in admin.


## Store/Restore fields_meta_data table
---------------------------------------

After changes are done in Studio, go to Admin and click 'Store Custom Fields'. That will store fields_meta_data table in custom/Extension/application/Ext/CustomFields/customfields.php

To restore fields_meta_data table:
After updating custom/Extension/application/Ext/CustomFields/customfields.php file (pulling code from git or similar) do Quick Repair & Rebuild first!
Then click on 'Custom Fields Rebuild' in Admin. This will check what fields will be added/updated/removed.
Only entries with newer date then one in db table will be used.
After confirmation fields_meta_data table will be updated. Then Quick Rebuild and Repair needs to be done again.
If some fields are deleted (they exist in db table but not in custom/Extension/application/Ext/CustomFields/customfields.php file) their content will be stored in custom/Extension/application/Ext/CustomFields/deleted_fields_meta_data.php

To delete a field:
After field is deleted in Studio, do 'Store custom fields'. After that in newly created customFieldsxxxx.php file (or new file in CustomFields folder) add
$deleteFields[] = '<field_id_from_fields_meta_data_table>';
Without this, because framework is using aggregated data from all customFields files, it is very likely that field will be rebuilt on next 'Rebuild Custom Fields' action.


## Rebuild configs
-------------------------------------

This part of plugin lets admin handle "requires_accounts" configuration in config_override.php (check http://support.sugarcrm.com/Documentation/Sugar_Developer/Sugar_Developer_Guide_7.7/User_Interface/Views/Removing_the_Account_Requirement_on_Opportunities/)

It will rebuild from files stored in custom/Extension/application/Ext/RequireAccounts

Files should be in format:
$requireAccounts[<module>] = {boolean}
Where module can be one of 'Contacts', 'Opportunities', 'Cases', 'Contracts'

By default all are set to true (that is SugarCRM default also if there is no value in config_override).

With this plugin Accounts will be required ONLY on modules that has set it's value to true in above files. Otherwise, if you set required_accounts=false in config_override all modules that is affected by it ('Contacts', 'Opportunities', 'Cases', 'Contracts') will not have required Accounts. To achieve that we update all views and subpanels to set 'required' for account_name field in them. If user manually edits them in studio this can be overriden, but if you run this plugin again it will fix issue and keep user's layout of view.

This will also rebuild any other config if it is set in $configs variable. Eg:

custom/Extension/application/Ext/RequireAccounts/configs.php

would need to have:

$configs[<config key>] = <config value>;



## Store/Restore Reports, Dashboards, Process Definitions and Email templates
-----------------------------------------------------------------------------

This is used to store/restore all tables related to Reports, Dashboards, Process Definitions, Email templates and Scheduled jobs. Data can be stored as many times as needed. Latest data (date_modified) will be used when restoring table contents. No data will be deleted from tables.
It will rebuild from files stored in custom/Extension/application/Ext/INT_RDPDET
Please note that standard scheduled jobs won't be stored/restored to avoid making duplicates.
