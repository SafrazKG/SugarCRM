<?php
$moduleList[] = 'INTDB_Dashboards';

$modInvisList[] = 'INTDB_Dashboards';

$adminOnlyList['INTDB_Dashboards'] = array(
    'all' => 1
);
