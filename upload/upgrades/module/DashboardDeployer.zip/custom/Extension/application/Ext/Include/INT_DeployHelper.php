<?php
$moduleList[] = 'INT_DeployHelper';

$modInvisList[] = 'INT_DeployHelper';

$adminOnlyList['INT_DeployHelper'] = array(
    'all' => 1
);
