<?php

    $mod_strings['LBL_INTDB_NAME'] = 'Intelestream Dashboards Deployer';
    $mod_strings['LBL_INTDB_DESCRIPTION'] = 'Intelestream Dashboards allow you to manage user\'s dashboards';
    $mod_strings['LBL_INTDB_ADMIN_HEADER'] = 'Intelestream Dashboards Deployer';
    $mod_strings['LBL_INTDB_ADMIN_DESCRIPTION'] = 'Intelestream Dashboards Deployer Manager';

    $mod_strings['LBL_INTDB_CONFIG_NAME'] = 'Intelestream Dashboards Deployer Configuration';
    $mod_strings['LBL_INTDB_CONFIG_DESCRIPTION'] = 'Intelestream Dashboards Configuration';
