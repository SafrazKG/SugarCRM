<?php
if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');

function post_install() {
    $autoexecute = false;
    $show_output = true;
    require_once("modules/Administration/QuickRepairAndRebuild.php");
    $randc = new RepairAndClear();
    $randc->repairAndClearAll(
        array('clearAll'),
        array(translate('LBL_ALL_MODULES')),
        $autoexecute,
        $show_output
    );
}