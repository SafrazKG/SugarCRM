<?php
$module_name = 'INTDB_Dashboards';

$viewdefs[$module_name]['base']['view']['config-content'] = array (
    'fields' => array (
        array (
            'name' => 'license_key',
            'label' => 'LBL_LICENSE_KEY',
        ),
        array (
            'name' => 'validation_key',
            'label' => 'LBL_VALIDATION_KEY',
        ),
    ),
);
