<?php
// created: 2016-07-05 17:59:41
$searchFields['DRI_SubWorkflows'] = array (
  'range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'start_range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'end_range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'start_range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'end_range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'range_progress' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_progress' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_progress' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_score' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_score' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_score' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_points' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_points' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_points' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
);