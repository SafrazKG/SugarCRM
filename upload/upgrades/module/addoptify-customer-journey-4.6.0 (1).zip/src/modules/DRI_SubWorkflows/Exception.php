<?php

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_SubWorkflows_Exception extends Exception
{

}
