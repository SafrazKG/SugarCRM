<?php

require_once 'modules/DRI_SubWorkflows/Exception.php';

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_SubWorkflows_Exception_NotFound extends DRI_SubWorkflows_Exception
{

}
