<?php

$module_name = 'DRI_SubWorkflows';
$viewdefs[$module_name]['mobile']['layout']['detail'] = array (
    'type' => 'detail',
    'components' =>
        array (
            0 =>
                array (
                    'view' => 'detail',
                )
        ),
);