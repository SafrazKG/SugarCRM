<?php

$module_name = 'DRI_SubWorkflows';
$viewdefs[$module_name]['mobile']['layout']['list'] = array (
    'type' => 'list',
    'components' =>
        array (
            0 =>
                array (
                    'view' => 'list',
                )
        ),
);