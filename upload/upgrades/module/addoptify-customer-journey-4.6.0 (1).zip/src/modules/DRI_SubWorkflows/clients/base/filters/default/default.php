<?php
// created: 2016-07-05 17:59:41
$viewdefs['DRI_SubWorkflows']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'sort_order' => 
    array (
    ),
    'score' => 
    array (
    ),
    'points' => 
    array (
    ),
    'dri_workflow_name' => 
    array (
    ),
    'dri_subworkflow_template_name' => 
    array (
    ),
    'state' => 
    array (
    ),
  ),
);