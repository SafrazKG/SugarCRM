<?php
// created: 2016-06-27 22:59:38
$searchFields['DRI_Workflow_Task_Templates'] = array (
  'name' => 
  array (
    'query_type' => 'default',
  ),
  'range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'start_range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'end_range_date_entered' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'start_range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'end_range_date_modified' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
    'is_date_field' => true,
  ),
  'range_task_due_days' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_task_due_days' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_task_due_days' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_sort_order' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_duration_hours' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_duration_hours' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_duration_hours' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'range_duration' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'start_range_duration' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
  'end_range_duration' => 
  array (
    'query_type' => 'default',
    'enable_range_search' => true,
  ),
);