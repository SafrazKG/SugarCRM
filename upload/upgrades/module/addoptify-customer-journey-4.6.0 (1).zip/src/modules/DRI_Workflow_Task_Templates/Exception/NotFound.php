<?php

require_once 'modules/DRI_Workflow_Task_Templates/Exception.php';

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_Workflow_Task_Templates_Exception_NotFound extends DRI_Workflow_Task_Templates_Exception
{

}
