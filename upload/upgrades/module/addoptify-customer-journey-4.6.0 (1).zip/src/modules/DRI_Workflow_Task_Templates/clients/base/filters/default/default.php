<?php
// created: 2016-06-27 22:59:38
$viewdefs['DRI_Workflow_Task_Templates']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'dri_subworkflow_template_name' => 
    array (
    ),
    'dri_workflow_template_name' => 
    array (
    ),
    'sort_order' => 
    array (
    ),
    'task_due_date_type' => 
    array (
    ),
    'task_due_days' => 
    array (
    ),
    'priority' => 
    array (
    ),
    'type' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
  ),
);