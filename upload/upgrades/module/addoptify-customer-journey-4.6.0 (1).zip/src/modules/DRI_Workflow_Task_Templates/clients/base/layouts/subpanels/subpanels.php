<?php

$moduleName = 'DRI_Workflow_Task_Templates';
$objectName = 'DRI_Workflow_Task_Template';

$viewdefs[$moduleName]['base']['layout']['subpanels'] = array (
    'components' => array (),
    'type' => 'subpanels',
    'span' => 12,
);
