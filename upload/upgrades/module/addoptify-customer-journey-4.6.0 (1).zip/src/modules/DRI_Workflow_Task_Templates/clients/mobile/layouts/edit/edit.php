<?php

$module_name = 'DRI_Workflow_Task_Templates';
$viewdefs[$module_name]['mobile']['layout']['edit'] = array (
    'type' => 'edit',
    'components' =>
        array (
            0 =>
                array (
                    'view' => 'edit',
                )
        ),
);