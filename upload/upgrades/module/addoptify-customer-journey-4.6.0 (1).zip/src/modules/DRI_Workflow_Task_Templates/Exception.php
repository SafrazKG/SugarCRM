<?php

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_Workflow_Task_Templates_Exception extends Exception
{

}
