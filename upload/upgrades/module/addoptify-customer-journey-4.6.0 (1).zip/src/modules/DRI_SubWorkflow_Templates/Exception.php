<?php

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_SubWorkflow_Templates_Exception extends Exception
{

}
