<?php
// created: 2016-07-05 17:59:24
$viewdefs['DRI_SubWorkflow_Templates']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'sort_order' => 
    array (
    ),
    'dri_workflow_template_name' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'related_activities' => 
    array (
    ),
    'points' => 
    array (
    ),
  ),
);