<?php
// created: 2017-02-22 15:46:23
$viewdefs['DRI_Workflow_Templates']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'active' => 
    array (
    ),
    'available_modules' => 
    array (
    ),
    'assignee_rule' => 
    array (
    ),
    'target_assignee' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
  ),
);