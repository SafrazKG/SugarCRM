<?php

$viewdefs['DRI_Workflow_Templates']['base']['view']['template-import'] = array(
    'panels' => array(
        array(
            'fields' => array(
                array(
                    'name' => 'template_import',
                    'type' => 'file',
                    'view' => 'edit',
                ),
            ),
        ),
    ),
);
