<?php

$viewdefs['DRI_Workflow_Templates']['base']['layout']['extra-info'] = array(
    'components' => array (
        array (
            'view' => 'dri-license-errors'
        ),
        array (
            'view' => 'designer'
        ),
    ),
    'type' => 'simple',
    'span' => 12,
);
