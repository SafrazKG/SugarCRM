<?php

$viewdefs['DRI_Workflow_Templates']['base']['layout']['designer'] = array (
    'components' => array (
        array (
            'view' => 'designer',
        ),
    ),
);
