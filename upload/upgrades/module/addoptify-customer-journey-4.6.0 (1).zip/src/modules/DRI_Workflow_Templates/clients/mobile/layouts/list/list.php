<?php

$module_name = 'DRI_Workflow_Templates';
$viewdefs[$module_name]['mobile']['layout']['list'] = array (
    'type' => 'list',
    'components' =>
        array (
            0 =>
                array (
                    'view' => 'list',
                )
        ),
);