<?php

$viewdefs['DRI_Workflow_Templates']['base']['layout']['template-import'] = array(
    'components' => array (
        array (
            'view' => 'template-import-headerpane',
        ),
        array(
            'view' => 'template-import',
        ),
    ),
    'type' => 'simple',
    'name' => 'base',
    'span' => 12,
);
