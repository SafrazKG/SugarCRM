<?php

$searchFields['DRI_Workflow_Templates'] = array (
    'name' => array ('query_type'=>'default'),
);
