<?php

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_Workflows_Exception extends Exception
{

}
