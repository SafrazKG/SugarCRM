<?php

$moduleName = 'DRI_Workflows';
$objectName = 'DRI_Workflow';

$viewdefs[$moduleName]['base']['layout']['subpanels'] = array (
    'components' => array (),
    'type' => 'subpanels',
    'span' => 12,
);
