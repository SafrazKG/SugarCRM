<?php

$viewdefs['DRI_Workflows']['base']['view']['configure-modules-content'] = array (
    'fields' => array (
        array (
            'name' => 'enabled_modules',
            'label' => 'LBL_ENABLED_MODULES',
            'type' => 'enum',
        ),
    ),
);
