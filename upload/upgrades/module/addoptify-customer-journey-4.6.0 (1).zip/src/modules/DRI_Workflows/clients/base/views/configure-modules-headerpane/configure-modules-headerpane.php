<?php

$viewdefs['DRI_Workflows']['base']['view']['configure-modules-headerpane'] = array (
    'template' => 'headerpane',
    'buttons' => array (),
);
