<?php

$viewdefs['DRI_Workflows']['base']['view']['config-headerpane'] = array (
    'template' => 'headerpane',
    'buttons' => array (
        array (
            'name' => 'sidebar_toggle',
            'type' => 'sidebartoggle',
        ),
    ),
);
