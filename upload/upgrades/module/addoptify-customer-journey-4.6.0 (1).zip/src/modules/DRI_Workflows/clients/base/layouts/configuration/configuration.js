({
    className: 'cj-configuration',
    initialize: function (options) {
        this._super("initialize", [options]);
    }
})
