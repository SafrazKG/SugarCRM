<?php

$viewdefs['DRI_Workflows']['base']['layout']['extra-info'] = array(
    'components' => array (
        array (
            'view' => 'dri-license-errors'
        ),
        array (
            'view' => 'dri-workflow'
        ),
    ),
    'type' => 'simple',
    'span' => 12,
);
