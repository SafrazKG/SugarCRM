<?php
// created: 2016-07-05 18:00:39
$viewdefs['DRI_Workflows']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'available_modules' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    'account_name' => 
    array (
    ),
    'opportunity_name' => 
    array (
    ),
    'contact_name' => 
    array (
    ),
    'case_name' =>
    array (
    ),
    'lead_name' => 
    array (
    ),
    'dri_workflow_template_name' => 
    array (
    ),
    'points' => 
    array (
    ),
    'assignee_rule' => 
    array (
    ),
    'score' => 
    array (
    ),
    'target_assignee' => 
    array (
    ),
    'current_stage_name' => 
    array (
    ),
    'state' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'team_name' => 
    array (
    ),
  ),
);