<?php

require_once 'modules/DRI_Workflows/Exception.php';

/**
 * @author Emil Kilhage <emil.kilhage@addoptify.com>
 */
abstract class DRI_Workflows_Exception_NotFound extends DRI_Workflows_Exception
{

}
