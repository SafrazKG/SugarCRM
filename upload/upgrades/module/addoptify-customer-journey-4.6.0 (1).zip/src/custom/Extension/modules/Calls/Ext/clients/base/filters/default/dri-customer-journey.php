<?php

$viewdefs['Calls']['base']['filter']['default']['fields']['cj_activity_tpl_name'] = array ();
$viewdefs['Calls']['base']['filter']['default']['fields']['dri_subworkflow_template_name'] = array ();
$viewdefs['Calls']['base']['filter']['default']['fields']['dri_workflow_template_name'] = array ();
$viewdefs['Calls']['base']['filter']['default']['fields']['is_customer_journey_activity'] = array ();
