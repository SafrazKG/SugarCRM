<?php

$mod_strings['LBL_DRI_WORKFLOW_SORT_ORDER'] = 'Customer Journey Order';
$mod_strings['LBL_CUSTOMER_JOURNEY_POINTS'] = 'Customer Journey Points';
$mod_strings['LBL_IS_CUSTOMER_JOURNEY_ACTIVITY'] = 'Is Customer Journey Call';
$mod_strings['LBL_CURRENT_CJ_ACTIVITY_AT'] = 'Current Customer Journey Activity At';
$mod_strings['LBL_CUSTOMER_JOURNEY_SCORE'] = 'Customer Journey Score';
$mod_strings['LBL_CUSTOMER_JOURNEY_PROGRESS'] = 'Customer Journey Progress';
$mod_strings['LBL_CJ_PARENT_ACTIVITY_TYPE'] = 'Customer Journey Parent Activity Type';
$mod_strings['LBL_CJ_PARENT_ACTIVITY_ID'] = 'Customer Journey Parent Activity Id';
$mod_strings['LBL_IS_CJ_PARENT_ACTIVITY'] = 'Is Customer Journey Parent Activity';
$mod_strings['LBL_CUSTOMER_JOURNEY_BLOCKED_BY'] = 'Customer Journey Blocked By';
