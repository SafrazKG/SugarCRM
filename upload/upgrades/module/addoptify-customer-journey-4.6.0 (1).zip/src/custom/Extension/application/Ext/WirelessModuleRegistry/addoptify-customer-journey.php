<?php

$wireless_module_registry['DRI_Workflows'] = array ('disable_create' => false);
