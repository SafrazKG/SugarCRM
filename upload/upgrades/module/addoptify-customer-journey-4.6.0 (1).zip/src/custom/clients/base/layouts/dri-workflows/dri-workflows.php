<?php

$viewdefs['base']['layout']['dri-workflows'] = array (
    'components' => array (
        array (
            'view' => 'dri-workflows-header'
        ),
    ),
    'type' => 'dri-workflows',
    'span' => 12,
);
